using System;
using System.Windows.Forms;

namespace HangmanGameWinForms
{
    public partial class FormStart : Form
    {
        private int secilenSure = 20;
        private string secilenZorluk = "Kolay";
        private string secilenTema = "Adam As"; // Varsay�lan tema

        public FormStart()
        {
            InitializeComponent();
        }

        private void btnStart_Click_1(object sender, EventArgs e)
        {
            if (comboBoxKategori.SelectedItem == null)
            {
                MessageBox.Show("L�tfen bir kategori se�iniz.");
                return;
            }

            string kategori = comboBoxKategori.SelectedItem.ToString();
            FormGame gameForm = new FormGame(kategori, secilenZorluk, secilenSure, secilenTema);
            gameForm.Show();
            this.Hide();
        }

        private void btnAyarlar_Click(object sender, EventArgs e)
        {
            FormSettings settings = new FormSettings();
            if (settings.ShowDialog() == DialogResult.OK)
            {
                secilenSure = settings.SecilenSure;
                secilenZorluk = settings.SecilenZorluk;
                secilenTema = settings.SecilenTema;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            // Arka plana t�klan�rsa yap�lacak bir i�lem yok
        }
    }
}

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace HangmanGameWinForms
{
    public partial class FormGame : Form
    {
        private string kategori;
        private string zorluk;
        private string tema;
        private int baslangicSure;
        private Label lblOyunBilgi;


        private string selectedWord;
        private string displayedWord;
        private int wrongGuesses = 0;
        private int score = 100;
        private int kalansure;

        private List<char> wrongLetters = new List<char>();

        private Dictionary<string, Dictionary<string, Dictionary<string, string>>> ipucuSozluk =
           new Dictionary<string, Dictionary<string, Dictionary<string, string>>>
       {
            {
                "Tarih", new Dictionary<string, Dictionary<string, string>>
                {
                    { "Kolay", new Dictionary<string, string>
                        {
                            { "roma", "Avrupa'da b�y�k bir imparatorluk" },
                            { "hitit", "Anadolu'da kurulan ilk uygarl�klardan biri" },
                            { "bizans", "�stanbul merkezli imparatorluk" }
                        }
                    },
                    { "Orta", new Dictionary<string, string>
                        {
                            { "sel�uk", "Malazgirt zaferini kazanan T�rk devleti" },
                            { "osmanl�", "600 y�l h�k�m s�ren imparatorluk" },
                            { "kanuni", "Muhte�em S�leyman olarak da bilinir" }
                        }
                    },
                    { "Zor", new Dictionary<string, string>
                        {
                            { "napolyon", "Waterloo�da yenildi" },
                            { "alparslan", "Malazgirt Meydan Muharebesi'ni kazand�" },
                            { "�anakkale", "1915�te direni�in ya�and��� cephe" }
                        }
                    }
                }
            },
            {
                "Matematik", new Dictionary<string, Dictionary<string, string>>
                {
                    { "Kolay", new Dictionary<string, string>
                        {
                            { "toplama", "�ki say�y� birle�tirme i�lemi" },
                            { "��karma", "Eksiltme i�lemi" },
                            { "b�lme", "E� par�alara ay�rma i�lemi" }
                        }
                    },
                    { "Orta", new Dictionary<string, string>
                        {
                            { "asal", "Sadece 1 ve kendisine b�l�n�r" },
                            { "karek�k", "Bir say�n�n karesi hangi say�ya e�itse" },
                            { "fakt�riyel", "Pozitif say�lar�n �arp�m�" }
                        }
                    },
                    { "Zor", new Dictionary<string, string>
                        {
                            { "logaritma", "�sl� say�lar�n ters i�lemidir" },
                            { "rasyonel", "Pay ve paydas� olan say�lar" },
                            { "geometri", "�ekillerle ilgilenen matematik dal�" }
                        }
                    }
                }
            },
            {
                    "Co�rafya", new Dictionary<string, Dictionary<string, string>>
                    {
                        { "Kolay", new Dictionary<string, string>
                            {
                                { "da�", "Y�ksek ve e�imli yer �ekli" },
                                { "nehir", "Akarsuya verilen bir di�er ad" },
                                { "delta", "Nehirlerin denize d�k�ld��� yerde olu�ur" }
                            }
                        },
                        { "Orta", new Dictionary<string, string>
                            {
                                { "orman", "A�a�larla kapl� geni� alan" },
                                { "volkan", "Lav p�sk�rten da� t�r�" },
                                { "kanyon", "Derin vadilere verilen ad" }
                            }
                        },
                        { "Zor", new Dictionary<string, string>
                            {
                                { "muson", "Mevsimsel r�zgar t�r�" },
                                { "tundra", "So�uk iklimdeki �orak alan" },
                                { "ekvator", "D�nyay� ikiye b�len �izgi" }
                            }
                        }
                    }
                },

            {
                "Genel K�lt�r", new Dictionary<string, Dictionary<string, string>>
                {
                    { "Kolay", new Dictionary<string, string>
                        {
                            { "kitap", "Okumak i�in yaz�l�r" },
                            { "film", "Sinemada izlenir" },
                            { "spor", "Fiziksel aktivite" }
                        }
                    },
                    { "Orta", new Dictionary<string, string>
                        {
                            { "internet", "Dijital ileti�im a��" },
                            { "m�zik", "Nota ve ritimle olu�ur" },
                            { "yemek", "A�l��� gideren �ey" }
                        }
                    },
                    { "Zor", new Dictionary<string, string>
                        {
                            { "psikoloji", "�nsan davran��lar�n� inceler" },
                            { "robot", "Programlanabilir makine" },
                            { "uzay", "D�nya d���ndaki sonsuz bo�luk" }
                        }
                    }
                }
            }
       };
        public FormGame(string kategori, string zorluk, int sure, string tema)
        {
            InitializeComponent();
            this.kategori = kategori;
            this.zorluk = zorluk;
            this.baslangicSure = sure;
            this.tema = tema;
            InitializeGame();
        }

        private void InitializeGame()
        {
            Dictionary<string, string> secilecekKelimeler;

            if (kategori == "Karma")
            {
                secilecekKelimeler = ipucuSozluk.Values
                    .Where(cat => cat.ContainsKey(zorluk))
                    .SelectMany(cat => cat[zorluk])
                    .ToDictionary(k => k.Key, v => v.Value);
            }
            else
            {
                secilecekKelimeler = ipucuSozluk[kategori][zorluk];
            }

            Random rnd = new Random();
            var kelimeler = secilecekKelimeler.Keys.ToList();
            selectedWord = kelimeler[rnd.Next(kelimeler.Count)];
            displayedWord = new string('_', selectedWord.Length);

            lblWord.Text = string.Join(" ", displayedWord.ToCharArray());
            lblClue.Text = "�pucu: " + secilecekKelimeler[selectedWord];
            lblScore.Text = "Score: " + score;

            string temaKodu = GetTemaKodu();
            pictureBox.Image = Image.FromFile($"Resources/{temaKodu}0.jpg");

            lblClue.Visible = false;
            kalansure = baslangicSure;
            lblTimer.Text = $"Time Left: {kalansure}s";
            timer1.Interval = 1000;
            timer1.Start();
            lblOyunBilgi.Text = $"S�re: {baslangicSure} sn - Kategori: {kategori} - Seviye: {zorluk}";

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            kalansure--;
            lblTimer.Text = $"Time Left: {kalansure}s";

            if (kalansure <= 0)
            {
                timer1.Stop();
                this.BackColor = Color.LightCoral;
                MessageBox.Show("S�re doldu! Oyun bitti.");
                this.Close();
            }
        }

        private void btnGuess_Click(object sender, EventArgs e)
        {
            string input = txtGuess.Text.ToLower();
            if (string.IsNullOrWhiteSpace(input) || input.Length != 1) return;

            char guess = input[0];
            txtGuess.Clear();

            if (selectedWord.Contains(guess))
            {
                char[] updatedDisplay = displayedWord.ToCharArray();
                for (int i = 0; i < selectedWord.Length; i++)
                    if (selectedWord[i] == guess)
                        updatedDisplay[i] = guess;

                displayedWord = new string(updatedDisplay);
                lblWord.Text = string.Join(" ", displayedWord.ToCharArray());

                if (!displayedWord.Contains('_'))
                {
                    timer1.Stop();
                    this.BackColor = Color.LightGreen;
                    MessageBox.Show("Tebrikler, kazand�n�z!");
                }
            }
            else
            {
                if (!wrongLetters.Contains(guess))
                {
                    wrongGuesses++;
                    score -= 10;
                    lblScore.Text = "Score: " + score;
                    wrongLetters.Add(guess);
                    lblWrongLetters.Text = "Wrong: " + string.Join(", ", wrongLetters);

                    string temaKodu = GetTemaKodu();
                    pictureBox.Image = Image.FromFile($"Resources/{temaKodu}{wrongGuesses}.jpg");

                    if (wrongGuesses >= 9)
                    {
                        timer1.Stop();
                        this.BackColor = Color.LightCoral;
                        MessageBox.Show("Kaybettiniz! Kelime: " + selectedWord);
                    }
                }
            }
        }

        private void btnHint_Click(object sender, EventArgs e)
        {
            lblClue.Visible = true;
        }

        private void btnEnd_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("Oyunu bitirmek istedi�inizden emin misiniz?", "Oyun Biti�", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
                this.Close();
        }

        private string GetTemaKodu()
        {
            return tema switch
            {
                "Adam As" => "hangman",
                "Buz K�rma" => "buz",
                "�i�ek Kopar" => "cicek",
                "Balon Patlat" => "balon",
                _ => "hangman"
            };
        }

        private void FormGame_Load(object sender, EventArgs e) { }
    }
}

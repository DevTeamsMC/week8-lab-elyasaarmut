﻿using System;
using System.Windows.Forms;

namespace HangmanGameWinForms
{
    public partial class FormSettings : Form
    {
        public int SecilenSure { get; private set; } = 20;
        public string SecilenZorluk { get; private set; } = "Kolay";
        public string SecilenTema { get; private set; } = "Adam As"; // Tema alanı eklendi

        public FormSettings()
        {
            InitializeComponent();
        }

        private void btnKaydet_Click(object sender, EventArgs e)
        {
            SecilenSure = (int)numericUpDownSure.Value;
            SecilenZorluk = comboBoxZorluk.SelectedItem?.ToString() ?? "Kolay";
            SecilenTema = comboBoxTema.SelectedItem?.ToString() ?? "Adam As"; // Tema değeri alınıyor
            DialogResult = DialogResult.OK;
            Close();
        }

        private void FormSettings_Load(object sender, EventArgs e)
        {
            comboBoxZorluk.SelectedIndex = 0;
            comboBoxTema.SelectedIndex = 0; // Tema default
            numericUpDownSure.Value = 20;
        }
    }
}

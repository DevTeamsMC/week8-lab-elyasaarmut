﻿using System.Drawing;
using System.Windows.Forms;

namespace HangmanGameWinForms
{
    partial class FormGame
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TextBox txtGuess;
        private System.Windows.Forms.Button btnGuess;
        private System.Windows.Forms.Label lblWord;
        private System.Windows.Forms.Label lblClue;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.Label lblTimer;
        private System.Windows.Forms.Label lblWrongLetters;
        private System.Windows.Forms.PictureBox pictureBox;
        private System.Windows.Forms.Button btnEnd;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btnHint;





        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            txtGuess = new TextBox();
            btnGuess = new Button();
            lblWord = new Label();
            lblClue = new Label();
            lblScore = new Label();
            lblWrongLetters = new Label();
            pictureBox = new PictureBox();
            btnEnd = new Button();
            lblTimer = new Label();
            btnHint = new Button();
            timer1 = new Timer(components);
            lblOyunBilgi = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox).BeginInit();
            SuspendLayout();
            // 
            // txtGuess
            // 
            txtGuess.Location = new Point(403, 236);
            txtGuess.MaxLength = 1;
            txtGuess.Name = "txtGuess";
            txtGuess.Size = new Size(50, 27);
            txtGuess.TabIndex = 0;
            // 
            // btnGuess
            // 
            btnGuess.Location = new Point(459, 233);
            btnGuess.Name = "btnGuess";
            btnGuess.Size = new Size(75, 30);
            btnGuess.TabIndex = 1;
            btnGuess.Text = "Guess";
            btnGuess.UseVisualStyleBackColor = true;
            btnGuess.Click += btnGuess_Click;
            // 
            // lblWord
            // 
            lblWord.BackColor = SystemColors.Control;
            lblWord.Font = new Font("Californian FB", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblWord.Location = new Point(309, 154);
            lblWord.Name = "lblWord";
            lblWord.Size = new Size(316, 42);
            lblWord.TabIndex = 2;
            lblWord.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblClue
            // 
            lblClue.BackColor = SystemColors.Control;
            lblClue.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lblClue.Location = new Point(309, 127);
            lblClue.Name = "lblClue";
            lblClue.Size = new Size(316, 27);
            lblClue.TabIndex = 3;
            // 
            // lblScore
            // 
            lblScore.BackColor = Color.Peru;
            lblScore.Font = new Font("Snap ITC", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            lblScore.ForeColor = SystemColors.ControlText;
            lblScore.Location = new Point(12, 328);
            lblScore.Name = "lblScore";
            lblScore.Size = new Size(231, 52);
            lblScore.TabIndex = 4;
            lblScore.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblWrongLetters
            // 
            lblWrongLetters.BackColor = SystemColors.Control;
            lblWrongLetters.Location = new Point(309, 207);
            lblWrongLetters.Name = "lblWrongLetters";
            lblWrongLetters.Size = new Size(316, 23);
            lblWrongLetters.TabIndex = 5;
            // 
            // pictureBox
            // 
            pictureBox.Location = new Point(12, 59);
            pictureBox.Name = "pictureBox";
            pictureBox.Size = new Size(231, 266);
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox.TabIndex = 6;
            pictureBox.TabStop = false;
            // 
            // btnEnd
            // 
            btnEnd.BackColor = SystemColors.Control;
            btnEnd.Location = new Point(421, 269);
            btnEnd.Name = "btnEnd";
            btnEnd.Size = new Size(100, 30);
            btnEnd.TabIndex = 7;
            btnEnd.Text = "End Game";
            btnEnd.UseVisualStyleBackColor = false;
            btnEnd.Click += btnEnd_Click;
            // 
            // lblTimer
            // 
            lblTimer.AutoSize = true;
            lblTimer.Font = new Font("Stencil", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            lblTimer.ForeColor = SystemColors.Desktop;
            lblTimer.Location = new Point(12, 23);
            lblTimer.Name = "lblTimer";
            lblTimer.Size = new Size(216, 33);
            lblTimer.TabIndex = 4;
            lblTimer.Text = "Time Left: 20s";
            // 
            // btnHint
            // 
            btnHint.BackColor = Color.Peru;
            btnHint.Location = new Point(309, 95);
            btnHint.Name = "btnHint";
            btnHint.Size = new Size(64, 29);
            btnHint.TabIndex = 8;
            btnHint.Text = "Hint:";
            btnHint.UseVisualStyleBackColor = false;
            btnHint.Click += btnHint_Click;
            // 
            // timer1
            // 
            timer1.Interval = 1000;
            timer1.Tick += timer1_Tick;
            // 
            // lblOyunBilgi
            // 
            lblOyunBilgi.Font = new Font("Stencil", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lblOyunBilgi.Location = new Point(262, 317);
            lblOyunBilgi.Name = "lblOyunBilgi";
            lblOyunBilgi.Size = new Size(363, 84);
            lblOyunBilgi.TabIndex = 0;
            // 
            // FormGame
            // 
            ClientSize = new Size(637, 410);
            Controls.Add(lblOyunBilgi);
            Controls.Add(btnHint);
            Controls.Add(lblTimer);
            Controls.Add(txtGuess);
            Controls.Add(btnGuess);
            Controls.Add(lblWord);
            Controls.Add(lblClue);
            Controls.Add(lblScore);
            Controls.Add(lblWrongLetters);
            Controls.Add(pictureBox);
            Controls.Add(btnEnd);
            Name = "FormGame";
            Text = "Hangman - Game";
            Load += FormGame_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }
    }
}

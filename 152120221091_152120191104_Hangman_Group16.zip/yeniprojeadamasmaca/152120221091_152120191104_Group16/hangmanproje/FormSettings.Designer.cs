﻿using System.Windows.Forms;

namespace HangmanGameWinForms
{
    partial class FormSettings
    {
        private NumericUpDown numericUpDownSure;
        private ComboBox comboBoxZorluk;
        private ComboBox comboBoxTema; // Yeni ComboBox
        private Button btnKaydet;
        private Label label1, label2, label3; // Yeni label

        private void InitializeComponent()
        {
            numericUpDownSure = new NumericUpDown();
            comboBoxZorluk = new ComboBox();
            comboBoxTema = new ComboBox(); // Tema kutusu
            btnKaydet = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label(); // Tema etiketi

            // numericUpDownSure
            numericUpDownSure.Location = new System.Drawing.Point(30, 50);
            numericUpDownSure.Minimum = 10;
            numericUpDownSure.Maximum = 120;
            numericUpDownSure.Value = 20;

            // comboBoxZorluk
            comboBoxZorluk.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxZorluk.Items.AddRange(new object[] { "Kolay", "Orta", "Zor" });
            comboBoxZorluk.Location = new System.Drawing.Point(30, 110);

            // comboBoxTema (yeni)
            comboBoxTema.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxTema.Items.AddRange(new object[] {
                "Adam As", "Buz Kırma", "Balon Patlat"
            });
            comboBoxTema.Location = new System.Drawing.Point(30, 170);

            // label1
            label1.Text = "Süre (saniye):";
            label1.Location = new System.Drawing.Point(30, 25);

            // label2
            label2.Text = "Zorluk:";
            label2.Location = new System.Drawing.Point(30, 85);

            // label3 (tema)
            label3.Text = "Tema:";
            label3.Location = new System.Drawing.Point(30, 145);

            // btnKaydet
            btnKaydet.Text = "Kaydet";
            btnKaydet.Location = new System.Drawing.Point(30, 210);
            btnKaydet.Click += btnKaydet_Click;

            // FormSettings
            ClientSize = new System.Drawing.Size(220, 260);
            Controls.Add(numericUpDownSure);
            Controls.Add(comboBoxZorluk);
            Controls.Add(comboBoxTema); // Ekleme
            Controls.Add(btnKaydet);
            Controls.Add(label1);
            Controls.Add(label2);
            Controls.Add(label3); // Ekleme
            Text = "Ayarlar";
            Load += FormSettings_Load;
            ResumeLayout(false);
        }
    }
}

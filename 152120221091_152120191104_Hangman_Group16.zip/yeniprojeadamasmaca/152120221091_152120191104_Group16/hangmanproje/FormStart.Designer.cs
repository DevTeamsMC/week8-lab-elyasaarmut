﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace HangmanGameWinForms
{
    partial class FormStart
    {
        private ComboBox comboBoxKategori;
        private Button btnStart;
        private Button btnAyarlar;
        private Label label1;
        private PictureBox pictureBox1;

        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            btnStart = new Button();
            btnAyarlar = new Button();
            label1 = new Label();
            comboBoxKategori = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.cover2;
            pictureBox1.Location = new Point(1, -1);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(747, 445);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // btnStart
            // 
            btnStart.Location = new Point(321, 289);
            btnStart.Name = "btnStart";
            btnStart.Size = new Size(139, 52);
            btnStart.TabIndex = 3;
            btnStart.Text = "Start Game";
            btnStart.Click += btnStart_Click_1;
            // 
            // btnAyarlar
            // 
            btnAyarlar.Location = new Point(321, 350);
            btnAyarlar.Name = "btnAyarlar";
            btnAyarlar.Size = new Size(139, 40);
            btnAyarlar.TabIndex = 4;
            btnAyarlar.Text = "Ayarlar";
            btnAyarlar.Click += btnAyarlar_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Snap ITC", 22.2F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(270, 190);
            label1.Name = "label1";
            label1.Size = new Size(266, 48);
            label1.TabIndex = 1;
            label1.Text = "HANGMAN";
            // 
            // comboBoxKategori
            // 
            comboBoxKategori.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxKategori.Items.AddRange(new object[] { "Tarih", "Coğrafya", "Matematik", "Genel Kültür", "Karma" });
            comboBoxKategori.Location = new Point(300, 250);
            comboBoxKategori.Name = "comboBoxKategori";
            comboBoxKategori.Size = new Size(180, 28);
            comboBoxKategori.TabIndex = 2;
            // 
            // FormStart
            // 
            ClientSize = new Size(748, 445);
            Controls.Add(label1);
            Controls.Add(comboBoxKategori);
            Controls.Add(btnStart);
            Controls.Add(btnAyarlar);
            Controls.Add(pictureBox1);
            Name = "FormStart";
            Text = "Hangman - Start";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }
    }
}
